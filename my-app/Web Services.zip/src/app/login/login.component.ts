import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { User } from '../User';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user: User;
  loginStatus: number;
  userAvailable: number;
  registeredUsers: any[];

  constructor() {
    this.user = new User();
    this.loginStatus = -1;
    this.userAvailable = -1;
    this.registeredUsers = this.user.registeredUsers;
   }

  ngOnInit() {
  }

  login(loginForm){
    for(let i=0;i<this.registeredUsers.length;i++)
    {
      if(this.registeredUsers[i].userName == loginForm.form.value.userName && this.registeredUsers[i].password == loginForm.form.value.password)
      {
        this.loginStatus = 1;
        break;
      }
      else
        this.loginStatus = 0;
    }
  }
}
