import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  posts: any[];
  todos: any[];
  users: any[];
  comments: any[];

  constructor (public http: Http){
    this.http.get('https://jsonplaceholder.typicode.com/posts')
    .map(res => res.json())
    .subscribe( res => {
      this.posts = res;
    });

    this.http.get('https://jsonplaceholder.typicode.com/todos')
    .map(res => res.json())
    .subscribe( res => {
      this.todos = res;
    });

    this.http.get('https://jsonplaceholder.typicode.com/users')
    .map(res => res.json())
    .subscribe( res => {
      this.users = res;
    }); 
  } 

  renderCommentsByPost(postID){
    this.http.get('https://jsonplaceholder.typicode.com/comments?postId=' + postID)
    .map(res => res.json())
    .subscribe( res => {
      this.comments = res;
    });
  }
}